import { OrderedItem } from './OrderedItem';

export class Transaction {


    transId:string;
    ordItem:OrderedItem;
    paymentMode:string;

}
 





