package com.capgemini.Service;
import com.capgemini.model.User1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.BankApplicationDao;
import com.capgemini.dao.BankApplicationDaoImpl;
@Service
public class BankServiceImpl implements BankService{
   @Autowired
	BankApplicationDao dao;
	
	public double showBalance(String userName) {
		dao.beginTransaction();
		double bal=dao.get_Balance(userName);
		dao.commitTransaction();
		return bal;
	}

	public double deposit(String userName, double amount) {
		dao.beginTransaction();
		double total_bal=dao.deposit_money(userName,  amount);
		dao.commitTransaction();
		return total_bal;
	}

	public double Withdraw(String userName, double amount) {
		dao.beginTransaction();
		double total_bal=dao.Withdraw_money(userName, amount);
		dao.commitTransaction();
		return total_bal;
	}

	public double fundTransfer(String userName,String username1,double amount) {
		dao.beginTransaction();
		double bal= dao.fund_Transfer(userName,username1, amount);
		dao.commitTransaction();
		return bal;
	}

	

	public void createAccount(User1 user) {
		System.out.print("hii");
		dao.beginTransaction();
		System.out.println(user);
		dao.createUserAccount(user);
		dao.commitTransaction();
		
	}

	public boolean validate(String userName)  {
		dao.beginTransaction();
		boolean res=dao.validate(userName);
		dao.commitTransaction();
		return res;
	}

	public boolean matchPass(String userName,String password) {
		dao.beginTransaction();
		boolean res=dao.matchPass(userName,password);
		dao.commitTransaction();
		
		return res;
	}

	public void printTransfer() {
		dao.printTransfer();
		
	}

	public List showAllUsers() {
		dao.beginTransaction();
		List<User1> list=dao.getAllUsers();
		dao.commitTransaction();
		return list;
	}

	

}
