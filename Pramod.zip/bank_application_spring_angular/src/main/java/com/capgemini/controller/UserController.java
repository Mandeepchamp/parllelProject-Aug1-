package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.Service.BankService;
import com.capgemini.model.User1;


@RestController
@RequestMapping(value="users")
@CrossOrigin(origins="http://localhost:4200")

public class UserController {
     @Autowired
	 private BankService service;
	 
	//http://localhost:9090/users/
     @RequestMapping(value="/", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
     public void addUser(@RequestBody User1 user){
    	 System.out.println("hii");
    	 service.createAccount(user);
    	 
     }
     
   //http://localhost:9090/users/
     @RequestMapping(value="/{username}", method=RequestMethod.GET)
     public double getBalance(@PathVariable("username")String name ){
    	 double bal=service.showBalance(name);
    	 return bal;
     }
     
     
   //http://localhost:9090/users/deposit/10000
     @RequestMapping(value="/deposit/{username}/{amount}", method=RequestMethod.GET)
     public double moneyDeposit(@PathVariable("username")String name,@PathVariable("amount")double amount){
    	 return service.deposit(name, amount);
     }
     
     //http://localhost:9090/users/withdraw/10000
     @RequestMapping(value="/withdraw/{username}/{amount}", method=RequestMethod.GET)
     public double withdrawmoney(@PathVariable("username")String name,@PathVariable("amount")double amount){
    	 return service.Withdraw(name, amount);
     }
     
     
     //http://localhost:9090/users/transfer/10000
     @RequestMapping(value="/transfer/{username}/{username1}/{amount}", method=RequestMethod.GET)
     public double fundTransfer(@PathVariable("username")String name,@PathVariable("username1")String name1,@PathVariable("amount")double amount){
    	 double balance= service.fundTransfer(name, name1, amount);
    	 System.out.print(balance);
    	 return balance;
     }
     
     
   //http://localhost:9090/users/
     @RequestMapping(value="/", method=RequestMethod.GET)
     public List<User1> getAllUsers(){
    	 List<User1>list=service.showAllUsers();
    	 return list;
     }
     
     @RequestMapping(value="/check/{username}/{password}", method=RequestMethod.GET)
     public boolean login(@PathVariable("username")String name,@PathVariable("password")String pass){
    	 boolean res=service.matchPass(name, pass);
    	 System.out.print(res);
    	 return res;
     }
     
     
     
     
	
}
