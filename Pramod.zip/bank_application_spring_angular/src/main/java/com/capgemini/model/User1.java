package com.capgemini.model;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity

public class User1 {
	
	 @Id
     private String userName;
	 private String password;
	 private double balance;
	 private String contactNo;
	 private String emailId;
	 private String name;
	public User1(String userName, String password, double balance, String contactNo, String emailId, String name) {
		super();
		this.userName = userName;
		this.password = password;
		this.balance = balance;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.name = name;
	}
	public User1(){
		
	}
	@Override
	public String toString() {
		return "User1 [userName=" + userName + ", password=" + password + ", balance=" + balance + ", contactNo="
				+ contactNo + ", emailId=" + emailId + ", name=" + name + "]";
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	 
	
}
