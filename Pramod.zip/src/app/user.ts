
export class IUser
{
    userName:string;
    password:string;
    balance:number;
    contactNo:number;
    emailId:string;
    name:string;
    
    
    
}

