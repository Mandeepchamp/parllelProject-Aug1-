import { Component, OnInit } from '@angular/core';
import { IUser } from './user';
import { UserService } from './user.service';


 
@Component({
  selector: 'app-user-list',
  templateUrl: './displayuser.component.html'
  
})
export class UserListComponent implements OnInit {
 
  users: IUser[];
 
  constructor(private userService: UserService) {
  }
 
  ngOnInit() {
    this.userService.findAll().subscribe(data => {
      this.users = data;
    });
  }
}