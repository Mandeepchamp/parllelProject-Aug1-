import {Injectable} from '@angular/core';
import{IUser} from './user';
import{ HttpClient, HttpHeaders} from '@angular/common/http';
import {FormBuilder ,FormGroup, FormArray, FormControl, Validators} from '@angular/forms';
import { Observable } from 'rxjs';


@Injectable()

export class UserService{
    private usersUrl: string;
    private usersUrl2: string;
    private usersUrl3: string;
    private usersUrl4: string;
    private usersUrl5: string;
    constructor(private http: HttpClient) {
        this.usersUrl = 'http://localhost:9090/users/';
        this.usersUrl2 = 'http://localhost:9090/users/deposit';
        this.usersUrl3 = 'http://localhost:9090/users/withdraw';
        this.usersUrl4 = 'http://localhost:9090/users/transfer';
        this.usersUrl5 = 'http://localhost:9090/users/check';
      }
      public login(username:string,password:string):Observable<any>{
        return this.http.get<any>(this.usersUrl5+"/"+username+"/"+password);
      }
      public findAll(): Observable<IUser[]> {
        return this.http.get<IUser[]>(this.usersUrl);
      }
     
      public save(user: IUser) {
        console.log(user);
        return this.http.post<IUser>(this.usersUrl, user);
      }
      public viewBalance(username:string): Observable<any>{
        return this.http.get<any>(this.usersUrl+"/"+username);
  
        }
        public moneyDeposit(username: string,amount:number):Observable<any>
        {
         return this.http.get<any>(this.usersUrl2+"/"+username+"/"+amount);
         }
         public moneyWithdraw(username: string,amount:number):Observable<any>
         {
          return this.http.get<any>(this.usersUrl3+"/"+username+"/"+amount);
          }
          public fundTransfer(username: string,username1:string,amount:number):Observable<any>
          {
            console.log(username);
            console.log(username1);
           return this.http.get<any>(this.usersUrl4+"/"+username+"/"+username1+"/"+amount);
           }
    

}