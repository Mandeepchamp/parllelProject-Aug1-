import { Component } from "@angular/core";
import {FormBuilder ,FormGroup, FormArray, FormControl, Validators} from '@angular/forms';
import {Router, ActivatedRoute} from '@angular/router';
import { IUser } from "./user";
import {UserService } from "./user.service";

@Component({
    selector: 'emp-add',
    templateUrl: './addComponent.html'
})

export class AddUserComponent{

    user: IUser;
 
  constructor(private route: ActivatedRoute, private router:Router, 
    private userService :UserService) {
      this.user=new IUser();
    
  }
 
  onSubmit() {
    console.log(this.user);
    this.userService.save(this.user).subscribe(result => this.meth());
  }
  meth(): void {
   console.log("Added Successfully");
  }
 
  

   
    // empForm= new FormGroup({
    //     eid:new FormControl('',[Validators.required, Validators.minLength(2), Validators.maxLength(6)]),
    //     ename: new FormControl(null, Validators.pattern('[A-Z][a-z]+')),
    //     esal: new FormControl()
   
    // });

   
    

    // addEmp(empForm:FormGroup):void{

    //     console.log("....."+this.empForm.value);
    //     this.emp.empId=this.empForm.controls['eid'].value;
    //     this.emp.empName=this.empForm.controls['ename'].value;
    //     this.emp.empSalary=this.empForm.controls['esal'].value;

    //     console.log("EmpId:"+this.emp.empId )
    //     this.empSer.addEmployee(this.emp);
    //     this.router.navigate(['/getEmpData']);



    // }
}