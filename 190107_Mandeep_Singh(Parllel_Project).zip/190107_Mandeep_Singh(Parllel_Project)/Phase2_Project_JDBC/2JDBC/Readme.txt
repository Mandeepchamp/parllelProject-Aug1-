/*
Author: Mandeep Singh
ID:190107
*/
//Create Tables


CREATE TABLE BANKDETAILSUSER( 
name VARCHAR2(10),
ACCOUNTNO NUMBER(15),   
PIN NUMBER(10),
ADDRESS VARCHAR2(15), 
PHONENO VARCHAR2(10),   
BALANCE NUMBER(10),accNo number(15));

CREATE TABLE TRANSACTIONSUSER(
type VARCHAR2(10),
accNo number(15),
amount number(10),
transid number(8));