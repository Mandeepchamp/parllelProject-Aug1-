package com.capgi.dao;

import java.util.List;

import com.capgi.bean.WalletAccount;
import com.capgi.bean.WalletTransaction;

public interface WalletDao {

	WalletAccount createAccount(WalletAccount wallet);

	List<WalletAccount> getAccountDetails();

	WalletAccount getWalletById(Long accountNo);

	WalletAccount depositAmount(WalletAccount wallet);

	WalletAccount withdrawAmount(WalletAccount wallet);

	List<WalletAccount> fundTransferAmount(WalletAccount wallet1, WalletAccount wallet2);

	void createTansaction(WalletTransaction transaction);

	

}
