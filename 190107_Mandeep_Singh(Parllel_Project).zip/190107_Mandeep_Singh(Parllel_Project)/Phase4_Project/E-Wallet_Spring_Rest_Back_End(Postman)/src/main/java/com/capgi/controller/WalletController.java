package com.capgi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capgi.bean.WalletAccount;
import com.capgi.bean.WalletTransaction;
import com.capgi.service.WalletServiceInterface;

@RestController
public class WalletController {

	@Autowired
	WalletServiceInterface service;
	 //Create Wallet Account and Adding Account details
	 @PostMapping(path="/createAccount",consumes="application/json")
	   public WalletAccount createAccount(@RequestBody WalletAccount wallet) {
		 return service.createAccount(wallet);
	  }
	 
	 //Getting Wallet Account Details
	 @GetMapping(path="/getDetails")
		public List<WalletAccount> getAccountDetails() {
			
			return service.getAccountDetails();
		}
	
	 
	 
	 //Deposit Amount in Wallet
	 @PutMapping(path="/deposit/{accountNo}/{amount}",consumes="application/json")
	 public WalletAccount depositAmount(@PathVariable Long accountNo,@PathVariable double amount,@RequestBody WalletTransaction transaction) {
		 WalletAccount wallet = service.getWalletById(accountNo);
		 double balance = wallet.getBalance()+amount;
		      wallet.setBalance(balance);
		       transaction.setAccount(accountNo);
		       transaction.setDebited(amount);
		       transaction.setCredited(0);
		       transaction.setBalance(balance);
		       service.createTansaction(transaction);
		    
		       
		 return service.depositAmount(wallet);
	 }

    //Withdraw Amount in Wallet
	 @PutMapping(path="/withdraw/{accountNo}/{amount}",consumes="application/json")
	 public WalletAccount withdrawAmount(@PathVariable Long accountNo,@PathVariable double amount,@RequestBody WalletTransaction transaction) {
		WalletAccount wallet = service.getWalletById(accountNo);
		  double balance = wallet.getBalance()-amount;
		    wallet.setBalance(balance); 
		    transaction.setAccount(accountNo);
		       transaction.setDebited(0);
		       transaction.setCredited(amount);
		       transaction.setBalance(balance);
		       service.createTansaction(transaction);
		 return service.withdrawAmount(wallet);
	 }
	 
	 @PutMapping(path="/fundTransferAmount/{accountNo1}/{accountNo2}/{amount}",consumes="application/json")
	 public List<WalletAccount> fundTransferAmount(@PathVariable Long accountNo1,@PathVariable Long accountNo2,@PathVariable double amount) {
		 WalletAccount wallet1 = service.getWalletById(accountNo1);
			double balanceWithdraw = wallet1.getBalance()-amount;
			    wallet1.setBalance(balanceWithdraw); 
	     
	     WalletAccount wallet2 = service.getWalletById(accountNo2);
		    double balanceDeposit = wallet2.getBalance()+amount;
				 wallet2.setBalance(balanceDeposit);
				
		  return service.fundTransferAmount(wallet1,wallet2);
	 }
 
}
