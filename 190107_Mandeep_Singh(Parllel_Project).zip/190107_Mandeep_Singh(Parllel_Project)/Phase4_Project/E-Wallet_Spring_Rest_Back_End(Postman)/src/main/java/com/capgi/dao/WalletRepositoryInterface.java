package com.capgi.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgi.bean.WalletAccount;



@Repository
public interface WalletRepositoryInterface extends JpaRepository<WalletAccount, Long>{

	

}
