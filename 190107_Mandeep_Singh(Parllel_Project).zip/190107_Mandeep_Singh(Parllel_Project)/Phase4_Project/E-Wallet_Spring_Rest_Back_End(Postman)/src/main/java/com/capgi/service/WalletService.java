package com.capgi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgi.bean.WalletAccount;
import com.capgi.bean.WalletTransaction;
import com.capgi.dao.WalletDao;

@Service
public class WalletService implements WalletServiceInterface{

    @Autowired
	WalletDao  dao;

	@Override
	public WalletAccount createAccount(WalletAccount wallet) {
		
		return dao.createAccount(wallet);
	}

	@Override
	public List<WalletAccount> getAccountDetails() {
		
		return dao.getAccountDetails();
	}

	@Override
	public WalletAccount getWalletById(Long accountNo) {
		
		return dao.getWalletById(accountNo);
	}

	@Override
	public WalletAccount depositAmount(WalletAccount wallet) {
		
		      
		return dao.depositAmount(wallet);
		
	}

	@Override
	public WalletAccount withdrawAmount(WalletAccount wallet) {
		
		return dao.withdrawAmount(wallet);
	}

	@Override
	public List<WalletAccount> fundTransferAmount(WalletAccount wallet1, WalletAccount wallet2) {
		
		return dao.fundTransferAmount(wallet1,wallet2);
	}

	@Override
	public void createTansaction(WalletTransaction transaction) {

		dao.createTansaction(transaction);		
	}

	
}
