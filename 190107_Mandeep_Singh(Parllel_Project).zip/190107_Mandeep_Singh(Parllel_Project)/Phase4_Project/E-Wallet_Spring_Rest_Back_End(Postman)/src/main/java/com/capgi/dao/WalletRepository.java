package com.capgi.dao;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.capgi.bean.WalletAccount;
import com.capgi.bean.WalletTransaction;

@Repository
public class WalletRepository implements WalletDao{

	@Autowired
	WalletRepositoryInterface repo;
	@Autowired
	WalletTransactionRepositoryInterface transRepo;
	//if you ask to speak teenager and teacher what would you tell them and why
	@Override
	public WalletAccount createAccount(WalletAccount wallet) {
		
		return repo.save(wallet);
	}

	@Override
	public List<WalletAccount> getAccountDetails() {
		
		return repo.findAll();
	}

	@Override
	public WalletAccount getWalletById(Long accountNo) {
		return repo.findById(accountNo).orElse(new WalletAccount());
	}

	@Override
	public WalletAccount depositAmount(WalletAccount wallet) {
		
	    return repo.save(wallet);
	}

	@Override
	public WalletAccount withdrawAmount(WalletAccount wallet) {
		
		return repo.save(wallet);
	}

	@Override
	public List<WalletAccount> fundTransferAmount(WalletAccount wallet1, WalletAccount wallet2) {
		List<WalletAccount> list = new LinkedList<WalletAccount>();
		 list.add(repo.save(wallet1));
		 list.add(repo.save(wallet2));
		 return list;
		
	}

	@Override
	public void createTansaction(WalletTransaction transaction) {
		transRepo.save(transaction);
		
	}

}
