package com.capgi.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgi.bean.WalletAccount;
import com.capgi.bean.WalletTransaction;
@Repository
public interface WalletTransactionRepositoryInterface extends JpaRepository<WalletTransaction, Long>{

}
