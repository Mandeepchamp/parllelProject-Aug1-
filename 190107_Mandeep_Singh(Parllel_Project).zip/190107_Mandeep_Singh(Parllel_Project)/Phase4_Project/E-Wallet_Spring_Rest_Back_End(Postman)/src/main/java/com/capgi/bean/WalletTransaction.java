package com.capgi.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="WALLET_TANSACTIONSUSER")
public class WalletTransaction {
	 @Id
	double account;
   double credited;
   double debited;
   double balance;

public double getAccount() {
	return account;
}
public void setAccount(double account) {
	this.account = account;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public double getCredited() {
	return credited;
}
public void setCredited(double credited) {
	this.credited = credited;
}
public double getDebited() {
	return debited;
}
public void setDebited(double debited) {
	this.debited = debited;
}
@Override
public String toString() {
	return "WalletTransaction [account=" + account + ", credited=" + credited + ", debited=" + debited + ", balance="
			+ balance + "]";
}

   
}
