package com.capgi.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
/*
 * 
 * Author : Mandeep Singh
   Id: 190107
 */

/*
 * Create Account
 */
@Component
@Entity
@Table(name="WALLET_ACCOUNTS")
public class WalletAccount {
  
	@SequenceGenerator(name="seq" , sequenceName = "order_seq")
    @GeneratedValue(generator = "seq")
    @Id
    /*
     * variables
     */
	private Long accountNo;
	private String customerName;
	private String custAddress;
	private Long custPhoneNo;
	private double balance;
	@OneToOne
	private WalletTransaction transaction;
	
	// Getter and setter
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public Long getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(Long custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "WalletAccount [accountNo=" + accountNo + ", customerName=" + customerName + ", custAddress="
				+ custAddress + ", custPhoneNo=" + custPhoneNo + ", balance=" + balance + "]";
	}
	
	
}
