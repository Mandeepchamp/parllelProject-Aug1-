package com.cg.service;

import com.capgi.exceptions.AccountNotFoundException;
import com.capgi.exceptions.LowBalanceException;
import com.cg.bean.Account;
import com.cg.bean.Customer;
import com.cg.dao.DaoImpl;
/*
 * Name:Mandeep singh
 * ID: 190107
 */
public class ServiceImpl implements Service {
	
	DaoImpl dao = new DaoImpl();
	
	public void createCustomerService(Customer customer) {
		dao.beginTransaction();
		dao.createCustomerDao(customer);
		dao.commitTransaction();
	}
	
	public Account showBalanceService(int accountNo) throws AccountNotFoundException {
		dao.beginTransaction();
		Account account = dao.showBalanceDao(accountNo);
		if(account == null){
			throw new AccountNotFoundException();
		}
		dao.commitTransaction();
		return account;
	}
	
	public void depositService(int depositAccount, double depositAmount) throws AccountNotFoundException {
		dao.beginTransaction();
		Account account = dao.depositDao(depositAccount);
		if(account == null){
			throw new AccountNotFoundException();
		}
		account.setBalance(account.getBalance() + depositAmount);
		dao.commitTransaction();
	}
	
	public void withdrawService(int withdrawAccount, double withdrawAmount) throws AccountNotFoundException, LowBalanceException {
		dao.beginTransaction();
		Account account = dao.withdrawDao(withdrawAccount);
		if(account == null){
			throw new AccountNotFoundException();
		}
		if(account.getBalance() < withdrawAmount){
			throw new LowBalanceException();
		}
		account.setBalance(account.getBalance() - withdrawAmount);
		dao.commitTransaction();
	}
	
	public void fundTransferService(int senderAccountNo, int receiverAccountNo, double transferAmount) throws AccountNotFoundException, LowBalanceException {
		dao.beginTransaction();
		Account senderAccount = dao.showBalanceDao(senderAccountNo);
		Account receiverAccount = dao.showBalanceDao(receiverAccountNo);
		if(senderAccount == null|| receiverAccount ==null){
			throw new AccountNotFoundException();
		}
		if(senderAccount.getBalance() < transferAmount){
			throw new LowBalanceException();
		}
		senderAccount.setBalance(senderAccount.getBalance() - transferAmount);
		receiverAccount.setBalance(receiverAccount.getBalance() + transferAmount);
		dao.commitTransaction();
	}

}
