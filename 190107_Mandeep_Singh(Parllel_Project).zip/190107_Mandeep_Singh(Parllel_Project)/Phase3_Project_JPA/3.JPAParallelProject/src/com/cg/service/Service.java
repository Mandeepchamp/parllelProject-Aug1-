package com.cg.service;

import com.capgi.exceptions.AccountNotFoundException;
import com.capgi.exceptions.LowBalanceException;
import com.cg.bean.Account;
import com.cg.bean.Customer;

public interface Service {
	
	public abstract void createCustomerService(Customer customer);
	public abstract Account showBalanceService(int accountNo) throws AccountNotFoundException;
	public abstract void depositService(int depositAccount, double depositAmount) throws AccountNotFoundException;
	public abstract void withdrawService(int withdrawAccount, double withdrawAmount) throws AccountNotFoundException, LowBalanceException;
	public abstract void fundTransferService(int senderAccountNo, int receiverAccountNo, double transferAmount) throws AccountNotFoundException, LowBalanceException;

}
