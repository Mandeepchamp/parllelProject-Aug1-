package com.cg.ui;

import java.util.Scanner;

import com.capgi.exceptions.AccountNotFoundException;
import com.capgi.exceptions.LowBalanceException;

/*
 * Name:Mandeep singh
 * ID: 190107
 */

public class UiMain {
	static int id=0;
	public static void main(String[] args) throws AccountNotFoundException, LowBalanceException {
		
		 String s;
		   do{
		   System.out.println("\n");
		   System.out.println("***********************Menu***********************");
		    System.out.print("|1.Create Account|            ");
		    System.out.print("|2.Show Balance|            ");
		    System.out.println("\n");
		    System.out.print("|3.Deposit|                   ");
		    System.out.print("|4.Withdraw|            ");
		    System.out.println("\n");
		    System.out.print("|5.Fund Transfer|             ");
		    System.out.print("|6.Print Transaction|            ");
		    System.out.println("\n");
		   System.out.println("Choose Option: ");
			@SuppressWarnings("resource")
			Scanner sc=new Scanner(System.in);
			int choice=sc.nextInt();
			CustomerUi cuobj=new CustomerUi();
			switch(choice) {
				case 1:
					cuobj.createCustomer();
					break;
				case 2:
					cuobj.showBalance();
					break;
				case 3:
					cuobj.deposit();
					break;
				case 4:
					cuobj.withdraw();
					break;
				case 5:
					cuobj.fundTransfer();
					break;
				case 6:
					cuobj.printTransaction();
					break;
				case 7:
					System.exit(0);
			}	
			 System.out.println("\n");
			   System.out.println("If You Want continure :");
			    s = sc.next();
			   }while(s.equalsIgnoreCase("Y"));
	}
}
