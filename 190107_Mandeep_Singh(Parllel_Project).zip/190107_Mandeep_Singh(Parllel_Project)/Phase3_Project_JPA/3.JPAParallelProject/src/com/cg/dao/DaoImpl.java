package com.cg.dao;

import javax.persistence.EntityManager;

import com.cg.bean.Account;
import com.cg.bean.Customer;

/*
 * Name:Mandeep singh
 * ID: 190107
 */

public class DaoImpl implements Dao {
	
	private EntityManager entityManager;

	public DaoImpl() {
		entityManager = Util.getEntityManager();
	}
	
	public void createCustomerDao(Customer customer) {
		entityManager.persist(customer);
	}
	
	public Account showBalanceDao(int accountNo) {
		Account account = entityManager.find(Account.class, accountNo);
		return account;
	}
	
	public Account depositDao(int depositAccount) {
		Account account = entityManager.find(Account.class, depositAccount);
		return account;
	}
	
	public Account withdrawDao(int withdrawAccount) {
		Account account = entityManager.find(Account.class, withdrawAccount);
		return account;
	}
	
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

}
