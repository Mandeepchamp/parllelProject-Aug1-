package com.capgi.bean;

public class BankBean {

	/*
	 * Author:Mandeep Singh
	 * Id: 190107
	 */
	private String name;
	private long accNo;
	private int pin;
	private String address;
	private String phone;
	private int balance;

	String transactions = new String();

	/*
	 * Constructors
	 */
	public BankBean() {
		super();
	}

	public BankBean(String name2, int accNo2, int pin2, String add2, String phone2, int bal) {
		super();
	}
	
	public BankBean(String name, long accNo, int pin, String address, String phone, int balance) {
		super();
		this.name = name;
		this.accNo = accNo;
		this.pin = pin;
		this.address = address;
		this.phone = phone;
		this.balance = balance;
	}

	/*
	 * Getters & Setters
	 */
	public String getTrans() {
		return transactions;
	}

	public void setTrans(String string) {
		transactions = string;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone2) {
		this.phone = phone2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccNo() {
		return accNo;
	}

	public long setAccNo(long accNo2) {
		return this.accNo = accNo2;
	}

	public String getAddress() {
		return address;
	}

	public void setAdd(String address) {
		this.address = address;
	}

	/*
	 * To String Method
	 */
	@Override
	public String toString() {
		return "AccountDetails name =" + name + "\n accNo =" + accNo + "\n pin =" + pin + "\n address =" + address
				+ "\n phone =" + phone + "\nbalance =" + balance;
	}
}